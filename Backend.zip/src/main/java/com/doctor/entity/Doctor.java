package com.doctor.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
	
	
	@NotNull(message =" name is Required! ")
	private String name;
	
	@NotNull(message =" medicalHistory is Required! ")
	private String medicalHistory;
	
	@NotNull(message =" Date of Joining is Required! ")
	private String dateOfAppointment;
	
	private long age;
	
	public Doctor(@NotNull(message =" name is Required! ") String name,
	@NotNull(message =" medicalHistory is Required! ") String medicalHistory,
	@NotNull(message =" Date of Joining is Required! ")  String dateOfAppointment,
	@NotNull(message =" age is Required! ") long age) {
		super();
		this.name=name;
		this.medicalHistory=medicalHistory;
		this.dateOfAppointment=dateOfAppointment;
		this.age=age;
	}

	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getmedicalHistory() {
		return medicalHistory;
	}

	public void setmedicalHistory(String medicalHistory) {
		this.medicalHistory = medicalHistory;
	}

	public String getdateOfAppointment() {
		return dateOfAppointment;
	}

	public void setdateOfAppointment(String dateOfAppointment) {
		this.dateOfAppointment = dateOfAppointment;
	}

	public long getage() {
		return age;
	}

	public void setage(long age) {
		this.age = age;
	}
	
	

}
