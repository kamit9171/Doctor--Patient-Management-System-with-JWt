package com.doctor.services;


import java.util.List;
import java.util.Optional;

import com.doctor.entity.Doctor;

public interface DoctorService {
	//All the Function 
	
	public List<Doctor> getAllEmployees();
	
	public Doctor addEmployee(Doctor employee);
	
	public Boolean existById(Integer id);
	
	public Optional<Doctor> getEmployeeById(Integer id);
	
	public Optional<Doctor > updateEmployee(Integer id,Doctor employee);
	
	public void deleteEmployeeRecordById(Integer id);
	
	
	

}

