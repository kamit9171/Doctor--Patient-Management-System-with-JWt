package com.doctor.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.entity.Doctor;
import com.doctor.repository.DoctorRepository;



@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	DoctorRepository employeeRepository;

	// getAllEmployees method is used to get all the Doctor List and OrderBy
	// Ascending Order
	public List<Doctor> getAllEmployees() {
		return employeeRepository.findAllByOrderByIdAsc();
	}

	// getAllEmployees method is used to get all the Doctor List and OrderBy
	// Descending Order
/*	public List<Doctor> getAllEmployeesDesc() {
		return employeeRepository.findAllByOrderByIdDesc();
	}
*/
	// addEmployee method is used to create Doctor Record
	public Doctor addEmployee(Doctor employee) {
		return employeeRepository.save(employee);
	}

	public Boolean existById(Integer id) {
		return employeeRepository.existsById(id);
	}

	// getEmployeeById service method is used to return the Doctor from repository
	// by using of findById
	public Optional<Doctor> getEmployeeById(Integer id) {
		return employeeRepository.findById(id);
	}

	// updateEmployee method is used to update Doctor record by using of Id
	public Optional<Doctor> updateEmployee(Integer id, Doctor employee) {
		return employeeRepository.findById(id).map((emp) -> {
			emp.setname(employee.getname());
			emp.setmedicalHistory(employee.getmedicalHistory());
			emp.setdateOfAppointment(employee.getdateOfAppointment());
			emp.setage(employee.getage());
			return employeeRepository.save(emp);
		});
	}

	// deleteEmployeeRecordById method is used to delete Doctor by using of Id
	public void deleteEmployeeRecordById(Integer id) {
		employeeRepository.deleteById(id);
	}

}
