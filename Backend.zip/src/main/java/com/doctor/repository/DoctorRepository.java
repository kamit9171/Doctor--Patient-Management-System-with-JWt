package com.doctor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.doctor.entity.Doctor;

@Repository
public interface DoctorRepository extends JpaRepository <Doctor,Integer>{
	
	//findAllByOrderByIdAsc method is used to ORder by Doctor list in Ascending Order
	public List<Doctor> findAllByOrderByIdAsc();
	
	//findAllByOrderByIdDesc method is used to ORder by Doctor list in descending Order
	//public List<Doctor> findAllByOrderByDesc();

}
