
INSERT INTO USERS (id,username, password) VALUES (1,'admin','$2a$09$OJdjDxZQra4tFR7J11FLX.FZ5SyZfYPty0TX0jcuac0olmTlJjdg2');
INSERT INTO ROLES (id, name, user_id) VALUES(101,'ROLE_USER_2',1);