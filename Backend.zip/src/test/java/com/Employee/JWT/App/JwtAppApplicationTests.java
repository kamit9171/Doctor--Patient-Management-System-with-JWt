package com.Employee.JWT.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
