import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeLoginComponent } from './doctor-login.component';

describe('EmployeeLoginComponent', () => {
  let component: EmployeeLoginComponent;
  let fixture: ComponentFixture<EmployeeLoginComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeLoginComponent]
    });
    fixture = TestBed.createComponent(EmployeeLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
