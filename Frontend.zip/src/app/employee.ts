
export class Employee {

    id: number = 0;
    name: string = "";
    medicalHistory: string = "";
    dateOfAppointment: string = "";
    age: number = 0;
    
}